package com.example.albaceteponteenmarchayassirmouddencarlosmartinez2damv;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MapActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
    }

    public void reportParking(android.view.View view) {
        Toast.makeText(this, "¡Gracias por reservar una plaza libre!", Toast.LENGTH_SHORT).show();
    }
}

