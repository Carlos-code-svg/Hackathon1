package com.example.albaceteponteenmarchayassirmouddencarlosmartinez2damv;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class BusActivity extends AppCompatActivity {
    String[] horarios = {
            "Línea 1: 09:00, 10:00, 11:00",
            "Línea 2: 09:30, 10:30, 11:30",
            "Línea 3: 10:00, 11:00, 12:00"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus);

        ListView busList = findViewById(R.id.busList);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, horarios);
        busList.setAdapter(adapter);
    }
}

