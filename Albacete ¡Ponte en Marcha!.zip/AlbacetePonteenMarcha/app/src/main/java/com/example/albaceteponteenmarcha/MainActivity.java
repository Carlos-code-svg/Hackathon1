package com.example.albaceteponteenmarcha;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void openBus(View view) {
        startActivity(new Intent(this, BusActivity.class));
    }

    public void openMap(View view) {
        startActivity(new Intent(this, MapActivity.class));
    }

    public void openProfile(View view) {
        startActivity(new Intent(this, ProfileActivity.class));
    }

    public void openShare(View view) {
        startActivity(new Intent(this, ShareActivity.class));
    }
}






